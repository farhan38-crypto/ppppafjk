# Hatke Client

A local app for buying products cheap (via **buyhatke.com** price tracking) and running the shop that resells them.

## Shop manager (click **Shop** in the header)

| Page | What it does |
|---|---|
| **Dashboard** | Today's and this month's sales, gross and net profit, stock value, money customers owe you, a 30-day chart, low stock, best sellers |
| **New shipment** | One truck load. Add products (from a product page with **＋ Add to my inventory**, or existing / new ones), enter **your cost**, qty and **your asking price**, plus the truck's **transport charge** → **Add shipment to inventory** |
| **Inventory** | Stock, landed cost, **minimum price**, **your asking price vs the lowest online price** (Amazon, Flipkart…), stock value. **↻ Market prices** refreshes online prices for all linked products |
| **New bill** | Pick a customer (remembered by phone), add items from stock, set a discount % or price. The bill shows the **original price, the discount and your price**. Supports part payment and credit |
| **Bills** | Search and filter, print or save as PDF, share on WhatsApp, record payments against dues, cancel a bill (stock goes back) |
| **Shipments** | Every truck load, with the transport share of each item |
| **Finance** | Profit and loss, cash in and out, profit per product, expenses (rent, electricity…), CSV exports for Excel, full backup |
| **Customers** | Who bought what, and who owes you money |
| **Settings** | Shop name, address and GSTIN for bills, **minimum margin %**, bill number prefix, default GST % |

### The pricing rules
* **Landed cost / unit** = price you paid + your share of that purchase's transport. Everything in one truck shares the transport charge **by value**: a costlier item carries a bigger share.
* **Minimum selling price** = landed cost + **10%** (changeable in Settings). A bill with any item below this **can't be saved**.
* Buyhatke is only your **market reference**: link each product to its online listing to see whether your asking price beats Amazon / Flipkart. The app warns you when you're above the lowest online price.
* Stock is sold **first-in-first-out**, so profit always uses what those exact units cost you.

### Your data
Everything is stored in **`shop.db`** in this folder. Use **Finance → Download full backup** regularly and keep the copy somewhere safe.
Backups are also saved in `backups/`.

## Price tracker

- Search products by name, or paste an Amazon / Flipkart / Myntra / etc. link
- Product page: current price, lowest / average / highest, a buy-or-wait verdict, a price-history chart
- Prices for the same product on other stores, plus store coupons
- **Price alerts** (set / update / remove / list). These need a Buyhatke account, so the app asks you to log in with **email + OTP** the first time you use them

## Run (Windows)

Double-click `run.bat`. The first run creates a `.venv` and installs the dependencies. After that it opens http://127.0.0.1:8000 in your browser.

Or manually:

```
python -m venv .venv
.venv\Scripts\pip install -r requirements.txt
.venv\Scripts\python app.py
```

Needs Python 3.10+.

## How it works

Buyhatke has no public API, so this uses the same endpoints its website uses:

| Feature | Source |
|---|---|
| Search, product data, history, other stores, coupons | Server-rendered pages (`/search?product=…`, `/<anything>-<sitePos>-<internalPid>`, `/<store-url>`). The data embedded in each page is evaluated in a sandboxed V8 isolate (`mini-racer`, no file or network access) and turned into JSON |
| Login | `ext1.buyhatke.com/spend-apis/login/send-otp` → `verify-otp` (cookie session) |
| Price alerts | `ext1.buyhatke.com/spend-apis/paapis/{get,set,update,remove}PriceAlert` |

Your login cookies are saved in `session.json` next to the app, so you stay logged in. Delete that file or press **Log out** to sign out. **Don't share or commit `session.json`.**

## Files

- `buyhatke.py`: the client library (usable on its own: `Buyhatke().search("iphone 15")`)
- `app.py`: FastAPI server and JSON API (`/api/search`, `/api/product`, `/api/login/*`, `/api/alerts*`)
- `static/index.html`: the UI

## Caveats

- These are unofficial, undocumented endpoints. If Buyhatke changes its site, parts of this will break.
- Buyhatke sits behind Cloudflare. If it starts blocking non-browser requests, you'll see a "403 / bot protection" error.
- Google sign-in isn't supported, only email OTP. If your Buyhatke account was made with Google, OTP on the same email should still work.
- For personal use. Don't hammer their servers.
