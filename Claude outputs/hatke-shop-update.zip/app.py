"""Local web app: run `python app.py`, then open http://127.0.0.1:8000"""
import threading
import time
from collections import OrderedDict
from pathlib import Path

import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel

from buyhatke import Buyhatke, BuyhatkeError, NotLoggedIn
import shop

HERE = Path(__file__).parent
bh = Buyhatke(HERE / "session.json")
app = FastAPI(title="Buyhatke Client")
shop.init_db()
app.include_router(shop.router)


@app.exception_handler(NotLoggedIn)
async def _need_login(_: Request, exc: NotLoggedIn):
    # 401 tells the UI to pop up the login dialog
    return JSONResponse({"error": "login_required", "detail": str(exc)}, status_code=401)


@app.exception_handler(BuyhatkeError)
async def _bh_error(_: Request, exc: BuyhatkeError):
    return JSONResponse({"error": "buyhatke", "detail": str(exc)}, status_code=502)


@app.exception_handler(httpx.HTTPError)
async def _net_error(_: Request, exc: httpx.HTTPError):
    return JSONResponse({"error": "network", "detail": f"Couldn't reach Buyhatke: {exc}"}, status_code=502)


@app.get("/static/{name}")
def static_file(name: str):
    f = (HERE / "static" / name).resolve()
    if f.parent != (HERE / "static").resolve() or not f.is_file():
        raise HTTPException(404)
    return FileResponse(f)


@app.get("/")
def index():
    return FileResponse(HERE / "static" / "index.html")


# Small in-memory cache so typing (suggestions) and then pressing Enter (full
# results) only hits Buyhatke once per query.
_cache: OrderedDict[str, tuple[float, list]] = OrderedDict()
_cache_lock = threading.Lock()
CACHE_TTL, CACHE_MAX = 600, 200


def cached_search(q: str) -> list:
    key = " ".join(q.lower().split())
    now = time.time()
    with _cache_lock:
        hit = _cache.get(key)
        if hit and now - hit[0] < CACHE_TTL:
            _cache.move_to_end(key)
            return hit[1]
    items = bh.search(q)
    with _cache_lock:
        _cache[key] = (now, items)
        _cache.move_to_end(key)
        while len(_cache) > CACHE_MAX:
            _cache.popitem(last=False)
    return items


@app.get("/api/search")
def search(q: str):
    if not q.strip():
        raise HTTPException(400, "Empty query")
    return cached_search(q.strip())


@app.get("/api/suggest")
def suggest(q: str, limit: int = 6):
    """Top matches for the search-as-you-type dropdown."""
    q = q.strip()
    if len(q) < 2:
        return []
    keep = ("name", "price", "mrp", "image", "site_image", "path", "brand")
    return [{k: p.get(k) for k in keep} for p in cached_search(q)[:max(1, min(limit, 10))]]


@app.get("/api/product")
def product(path: str | None = None, url: str | None = None):
    return bh.product(path=path, url=url)


class Email(BaseModel):
    email: str


class Otp(BaseModel):
    otp: str


class NewAlert(BaseModel):
    product: dict
    target_price: float


class AlertUpdate(BaseModel):
    alert_id: str | int
    target_price: float


class AlertId(BaseModel):
    alert_id: str | int


@app.get("/api/login/status")
def login_status():
    return bh.login_status()


@app.post("/api/login/send-otp")
def send_otp(body: Email):
    return bh.send_otp(body.email)


@app.post("/api/login/verify-otp")
def verify_otp(body: Otp):
    res = bh.verify_otp(body.otp)
    return {"result": res, "status": bh.login_status()}


@app.post("/api/logout")
def logout():
    bh.logout()
    return {"ok": True}


@app.get("/api/alerts")
def alerts():
    return bh.alerts()


@app.post("/api/alerts")
def set_alert(body: NewAlert):
    return bh.set_alert(body.product, body.target_price)


@app.post("/api/alerts/update")
def update_alert(body: AlertUpdate):
    return bh.update_alert(body.alert_id, body.target_price)


@app.post("/api/alerts/remove")
def remove_alert(body: AlertId):
    return bh.remove_alert(body.alert_id)


# ---- market reference for shop products (Buyhatke = what the same item costs online)
class MarketLink(BaseModel):
    path: str | None = None      # Buyhatke product path to link; omit to refresh the existing link
    url: str | None = None       # or a store link (Amazon/Flipkart/...) to link


@app.post("/api/shop/products/{pid}/market")
def refresh_market(pid: int, body: MarketLink = MarketLink()):
    with shop.db() as con:
        row = con.execute("SELECT bh_path FROM products WHERE id=?", (pid,)).fetchone()
        if not row:
            raise HTTPException(404, "Product not found")
        path = body.path or row["bh_path"]
    if not path:
        raise HTTPException(400, "This product isn't linked to an online listing yet")
    m = shop.market_from_buyhatke(bh.product(path=path))
    with shop.db() as con:
        shop.set_market(con, pid, m)
    return m


@app.post("/api/shop/market/refresh-all")
def refresh_all_markets():
    with shop.db() as con:
        ids = [r["id"] for r in con.execute(
            "SELECT id FROM products WHERE active=1 AND bh_path IS NOT NULL AND bh_path<>''")]
    done, failed = 0, []
    for pid in ids:
        try:
            refresh_market(pid)
            done += 1
        except Exception as e:  # keep going; report which ones failed
            failed.append({"id": pid, "error": str(e).splitlines()[0][:140]})
        time.sleep(0.4)        # be gentle with Buyhatke
    return {"updated": done, "failed": failed}


if __name__ == "__main__":
    import uvicorn
    import webbrowser
    webbrowser.open("http://127.0.0.1:8000")
    uvicorn.run(app, host="127.0.0.1", port=8000)
